#ifndef LIBRARY_HPP
#define LIBRARY_HPP

#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace std;
#endif  // LIBRARY_HPP